Basic Calculator
-------------------

Installation
----------------

to use the package in your notebook:

``!pip install pip install basic-calculator-101==1.2``

``from calculator.calculator import Calculator``


Usage
--------

- calculator = Calculator()
- calculator.add(6)
- calculator.subtract(3)
- calculator.multiply(2)
- calculator.divide(5)
- calculator.reset_memory()


Features:
----------------

- Addition
- Subtraction: 
- Multiplication
- Division: 
- Take (n) root of number:
- Memory of last result: